const Discord = require('discord.js');

module.exports = {
  name: 'channelUpdate',
  run: async (client, oldChannel, newChannel) => {
    const guild = newChannel.guild.id;
    const color = client.db.get(`color_${guild}`) || client.config.default_color;
    let channel = client.db.get(`channellogs_${guild}`);
    if (!channel) return;

   
    if (oldChannel.type === 'GUILD_VOICE' || newChannel.type === 'GUILD_VOICE' || oldChannel.type === 'GUILD_TEXT' || newChannel.type === 'GUILD_TEXT' ) {

      const embed = new Discord.EmbedBuilder()
        .setColor(color)
        .setTitle("Mise à jour de canal vocal ou texte.")
        .setDescription(`Le canal vocal ou texte <#${oldChannel.id}>\` a été mis à jour.`)
        .addFields({ name: "Ancienne configuration", value: `Nom : \`${oldChannel.name}\`, Description : \`${oldChannel.topic || 'Aucune'}\``})
                 ({ name: "Nouvelle configuration", value: `Nom : \`${newChannel.name}\`, Description : \`${newChannel.topic || 'Aucune'}\``})
        .setTimestamp();

   
      const logChannelId = client.db.get(`channellogs_${guild.id}`);
      const logChannel = guild.channels.cache.get(logChannelId);

      if (logChannel) {
        logChannel.send({ embeds: [embed] });
      }
    } else {
     
      const changes = [];

      if (oldChannel.name !== newChannel.name) {
        changes.push(`> Le nom du salon a été changé : \`${oldChannel.name}\` → \`${newChannel.name}\``);
      }

      if (oldChannel.topic !== newChannel.topic) {
        changes.push(`> La description du salon a été changé : \`${oldChannel.topic || 'Aucune'}\` → \`${newChannel.topic || 'Aucune'}\``);
      }

      if (oldChannel.type !== newChannel.type) {
        changes.push(`> Le type de salon a été changé : \`${oldChannel.type}\` → \`${newChannel.type}\``);
      }

      if (oldChannel.guildOnly !== newChannel.guildOnly) {
        changes.push(`> La visibilitée du salon a été changé : \`${oldChannel.guildOnly}\` → \`${newChannel.guildOnly}\``);
      }

      if (changes.length > 0) {
     
        const embed = new Discord.EmbedBuilder()
          .setColor(color)
          .setTitle("Mise à jour d'un salon")
          .setDescription(`Le salon <#${oldChannel.id}> a été mis à jour.`)
          .addFields({name: "Changements", value: changes.join('\n')})
          .setTimestamp();

      
        const logChannelId = client.db.get(`channellogs_${guild.id}`);
        const logChannel = guild.channels.cache.get(logChannelId);

        if (logChannel) {
          logChannel.send({ embeds: [embed] });
        }
      }
    }
  },
};
