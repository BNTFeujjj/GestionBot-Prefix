const Astroia = require('../../structures/client/index');
const axios = require('axios');
const Discord  = require('discord.js');
const { EmbedBuilder } = require('discord.js');


  /**
   * 
   * @param {Astroia} client 
   * @param {Discord.Message} message
   * @param {string[]} args
   */
  module.exports = {
    name: "mybot",
    description: "Affiche l'invitation de votre bot.",
    usage: "mybot",
  run: async (client, message, args, commandName) => {
    let pass = false
    let staff = client.staff
    if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
        if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
        if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
        if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
        if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
        if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
        if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
    } else pass = true;
    if (pass === false) {
        if (client.noperm && client.noperm.trim() !== '') {
            return message.channel.send(client.noperm);
        } else {
            return;
        }
    }  
    try {
      const embed = new Discord.EmbedBuilder()
        .setTitle(`Vos bots`)
        .setDescription(`Cliquez ici pour inviter votre bot [${client.user.tag}](https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot)`);
        
      message.reply({ embeds: [embed] });
    } catch (error) {
      console.error(error);
      message.reply({ content: "Une erreur s'est produite." });
    }
  }
}