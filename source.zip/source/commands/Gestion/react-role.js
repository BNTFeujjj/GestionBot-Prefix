const { ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, ButtonBuilder, ButtonStyle, RoleSelectMenuBuilder, ChannelSelectMenuBuilder } = require('discord.js');
const ms = require('ms');
const Discord = require('discord.js')

module.exports = {
  name: "rolereact",
  aliases: ["setup-rolereact", "setuprolereact", "reactrole-setup", "reactrolesetup", "rr"],
  description: "Configure le rolereact.",
  /**
   * @param {Astroia} client 
   * @param {Discord.Message} message
   */
  run: async (client, message, args, commandName) => {
    let pass = false;
    let staff = client.staff;
    if (!staff.includes(message.author.id) && !client.config.buyers.includes(message.author.id) && client.db.get(`owner_${message.author.id}`) !== true) {
      if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "1" && message.member.roles.cache.some(r => client.db.get(`perm1.${message.guild.id}`)?.includes(r.id))) pass = true;
      if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "2" && message.member.roles.cache.some(r => client.db.get(`perm2.${message.guild.id}`)?.includes(r.id))) pass = true;
      if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "3" && message.member.roles.cache.some(r => client.db.get(`perm3.${message.guild.id}`)?.includes(r.id))) pass = true;
      if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "4" && message.member.roles.cache.some(r => client.db.get(`perm4.${message.guild.id}`)?.includes(r.id))) pass = true;
      if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "5" && message.member.roles.cache.some(r => client.db.get(`perm5.${message.guild.id}`)?.includes(r.id))) pass = true;
      if (client.db.get(`perm_${commandName}.${message.guild.id}`) === "public") pass = true;
    } else {
      pass = true;
    }

    if (pass === false) {
      if (client.noperm && client.noperm.trim() !== '') {
        return message.channel.send(client.noperm);
      } else {
        return;
      }
    }

    let msg = await message.reply({ content: 'Chargement en cours...' });

    async function update() {
      const db = client.db.get(`rolereact_${message.guild.id}`) || {
        status: false,
        role: [],
        channel: []
      };

      const status = db?.status === true ? '🟢' : '🔴';
      const role = db?.role;
      const channel = db?.channel;
      const rolename = role ? role.map(roleId => message.guild.roles.cache.get(roleId)?.name || "Inconnu") : [];

      const embed = new Discord.EmbedBuilder()
        .setColor(client.color)
        .setFooter(client.footer)
        .setTitle('Rolereact')
        .addFields(
          { name: 'Status :', value: `\`\`\`yml\n${status}\`\`\`` },
          { name: "Rôles à choisir :", value: `\`\`\`yml\n${rolename.join(', ') || "Aucun rôle défini"}\`\`\`` },
          { name: "Channel ou sera poster le rolereact :", value: `\`\`\`yml\n${channel}\`\`\`` },

        );

      const rowbutton = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId(`rolereact_active_${message.id}`)
            .setEmoji(db?.status === true ? '🟢' : '🔴')
            .setStyle(db?.status === true ? Discord.ButtonStyle.Success : Discord.ButtonStyle.Danger),
          new ButtonBuilder()
            .setCustomId(`rolereact_role_${message.id}`)
            .setLabel('Ajouter / Retire des rôles')
            .setStyle(Discord.ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId(`rolereact_channel_${message.id}`)
            .setLabel('Le channel')
            .setStyle(Discord.ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId(`rolereact_reset_${message.id}`)
            .setLabel('Reset')
            .setStyle(Discord.ButtonStyle.Danger),
          new ButtonBuilder()
            .setCustomId(`rolereact_post_${message.id}`)
            .setLabel('Envoyer')
            .setStyle(Discord.ButtonStyle.Secondary)
        );

      return msg.edit({ embeds: [embed], components: [rowbutton], content: null });
    }

    update();

    const collector = message.channel.createMessageComponentCollector({ filter: m => m.user.id == message.author.id, componentType: Discord.ComponentType.Button, time: ms("2m") });

    collector.on("collect", async (i) => {
      if (i.customId === `rolereact_post_${message.id}`) {

        let channeldb = client.db.get(`rolereact_${message.guild.id}`);
        if (!channeldb) {
          channeldb = {
            status: false,
            role: [],
            channel: []
          };
        }
        if (channeldb.status !== true || !channeldb.role || !channeldb.channelName) {
          return i.reply({ content: 'Configuration incomplète. Veuillez vérifier que les rôles, le canal et le statut sont correctement configurés.', ephemeral: true });
        }

      
 
        const db2 = client.db.get(`rolereact_${message.guild.id}`) || {
          status: false,
          role: [],
          channel: []
        };
        const roles = db2?.role.map(roleId => ({
          value: roleId,
          label: message.guild.roles.cache.get(roleId)?.name || "Inconnu",
        })) || [];
        const embed = new Discord.EmbedBuilder()
        .setColor(client.color)
        .setFooter(client.footer)
        .setTitle('Rôles')
        .setDescription('Choisissez un ou plusieurs rôle(s) à vous ajouter.')       
        .setImage('https://cdn.discordapp.com/attachments/1166712265161048094/1178034840466108496/standard.gif?ex=6574ad70&is=65623870&hm=86f58730bc075fc72cfd05a64944d824f437505897e678b0f5d85cf42883b2b9&')
        const rowRoleDropdown = new ActionRowBuilder()
    .addComponents(
        new StringSelectMenuBuilder()
            .setCustomId('rolereact_role_dropdown_' + message.id)
            .setPlaceholder('Faîtes un choix !')
            .addOptions(
                roles.map(role => new StringSelectMenuOptionBuilder()
                    .setLabel(role.label)
                    .setValue(role.value)
                )
            )
    );

        
    
        
        
        

        

        const channelName = channeldb.channelName;
        const channel = message.guild.channels.cache.find(ch => ch.name === channelName);

        
        if (channel) {
       
          await channel.send({ embeds: [embed], components: [rowRoleDropdown] });
         i.reply({ content: "Le reaction role à bien était poster dans le channel !", ephemeral: true});
          
  
        } else {
  
          i.reply({ content: "Le canal spécifié n'a pas été trouvé.", ephemeral: true });
        }
        
      }
    });

    client.on('interactionCreate', async (i) => {
      if (i.customId === `rolereact_role_dropdown_${message.id}`) {
        const db2 = client.db.get(`rolereact_${message.guild.id}`) || {
          status: false,
          role: [],
          channel: []
        };
        const roles = db2?.role.map(roleId => ({
          value: roleId,
          label: message.guild.roles.cache.get(roleId)?.name || "Inconnu",
        })) || [];
        const rolereactData = client.db.get(`rolereact_${message.guild.id}`) || { status: false, role: [], channel: [] };
        const selectedRoles = i.values;
        rolereactData.messageid = i.message.id;
        rolereactData.role = db2.role;
        rolereactData.channel = i.channel.id;

        client.db.set(`rolereact_${message.guild.id}`, rolereactData);
       

        const member = message.guild.members.cache.get(i.user.id);
        const existingRoles = member.roles.cache.filter(role => selectedRoles.includes(role.id));

        if (existingRoles.size > 0) {
        
          await member.roles.remove(existingRoles);
          i.reply({ content: 'Rôles retirés avec succès !', ephemeral: true });
         
        } else {

          for (const roleId of selectedRoles) {
            const role = message.guild.roles.cache.get(roleId);
            if (role) {
              await member.roles.add(role);
            }
          }
          i.reply({ content: 'Rôles ajoutés avec succès !', ephemeral: true });
        
        }
      }   
  

      if (i.customId === `rolereact_role_${message.id}`) {
        const rowrole = new RoleSelectMenuBuilder()
          .setCustomId('rolereact_role_select_' + message.id)
          .setMaxValues(1)
          .setMaxValues(25);
        const row = new ActionRowBuilder().addComponents(rowrole);
        const rowbutton = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('rolereact_role_retour_' + message.id)
              .setStyle(Discord.ButtonStyle.Danger)
              .setEmoji('◀')
          );
        i.update({ components: [row, rowbutton], embeds: [], content: "Merci de choisir les rôles a ajouter ou a supprimer" });
      }
    });

    client.on('interactionCreate', async (i) => {
      if (i.user.id !== message.author.id) return i.reply({ content: await client.lang('noperminterac'), ephemeral: true });

      if (i.customId === `rolereact_role_retour_${message.id}`) {
        update();
      } else if (i.customId === `rolereact_active_${message.id}`) {
        let db = client.db.get(`rolereact_${message.guild.id}`);
        const currentStatus = db?.status;
        const newStatus = currentStatus === null ? true : !currentStatus;
        db = { ...db, status: newStatus };
        client.db.set(`rolereact_${message.guild.id}`, db);
        const status = db?.status === true ? 'Le status a été activé avec succès' : 'Le status a été désactivé avec succès';
        const reply = await i.reply({ content: status, ephemeral: true });
        setTimeout(async () => {
          await reply.delete();
        }, ms('1s'));
        update();
      } else if (i.customId === `rolereact_reset_${message.id}`) {
        let reply = await i.reply({ content: '`✅` les paramètres ont été bien reset', ephemeral: true });
        client.db.delete(`rolereact_${message.guild.id}`);
        setTimeout(async () => {
          await reply.delete();
        }, ms('1s'));
        update();
      } else if (i.customId === `rolereact_role_select_${message.id}`) {
        const selectedRoles = i.values;
      
        let roledb = client.db.get(`rolereact_${message.guild.id}`);
        if (!roledb) {
          roledb = {
            status: false,
            role: [],
            channel: []
          };
        }

        const existingRoles = roledb.role || [];

        let rolesAdded = 0;
        let rolesRemoved = 0;
        let invalidRoles = 0;
        let inaccessibleRoles = 0;

        for (const roleId of selectedRoles) {
          const role = message.guild.roles.cache.get(roleId);

          if (!role) {
            invalidRoles++;
            continue;
          }

          if (role.managed) {
            inaccessibleRoles++;
            continue;
          }

          if (!role.editable) {
            inaccessibleRoles++;
            continue;
          }

          if (existingRoles.includes(roleId)) {
            const updatedRoles = existingRoles.filter(id => id !== roleId);
            roledb.role = updatedRoles;
            client.db.set(`rolereact_${message.guild.id}`, roledb);
            rolesRemoved++;
          } else {
            existingRoles.push(roleId);
            roledb.role = existingRoles;
            client.db.set(`rolereact_${message.guild.id}`, roledb);
            rolesAdded++;
          }
        }

        let response = '';

        if (rolesAdded > 0) {
          response += `Rôles Ajoutés : \`${rolesAdded} rôles\`\n`;
        }
        if (rolesRemoved > 0) {
          response += `Rôles Retirés : \`${rolesRemoved} rôles\`\n`;
        }
        if (invalidRoles > 0) {
          response += `Rôles Invalides : \`${invalidRoles} rôles\`\n`;
        }
        if (inaccessibleRoles > 0) {
          response += `Rôles Inaccessibles : \`${inaccessibleRoles} rôles\`\n`;
        }
        console.log('Response:', response);
        i.reply({ content: response, ephemeral: true });
        update();
      }
    });

    collector.on('end', () => {
      msg.edit({ components: [] });
    });

    const collectorchannel = message.channel.createMessageComponentCollector({ filter: m => m.user.id == message.author.id, componentType: Discord.ComponentType.Button, time: ms("2m") });
    collectorchannel.on("collect", async (i) => {
      if (i.customId === `rolereact_channel_${message.id}`) {
        const rowchannel = new ChannelSelectMenuBuilder()
          .setCustomId('rolereact_channel_select_' + message.id)
          .setMaxValues(1)
          .setMaxValues(1)
          .setChannelTypes(0);

        const row = new ActionRowBuilder().addComponents(rowchannel);
        const rowbutton = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('rolereact_channel_retour_' + message.id)
              .setStyle(Discord.ButtonStyle.Danger)
              .setEmoji('◀')
          );
        i.update({ components: [row, rowbutton], embeds: [], content: "Merci de choisir le canal où sera posté le captcha !" });
      }
    });

    client.on('interactionCreate', async (i) => {
      if (i.user.id !== message.author.id) return i.reply({ content: await client.lang('noperminterac'), ephemeral: true });

      if (i.customId === `rolereact_channel_retour_${message.id}`) {
        update();
      } else if (i.customId === `rolereact_channel_select_${message.id}`) {
        const selectedChannel = i.values[0];
     

        let channeldb = client.db.get(`rolereact_${message.guild.id}`);
        if (!channeldb) {
          channeldb = {
            status: false,
            role: [],
            channel: []
          };
        }

        const existingChannel = channeldb.channel || [];

        let channelAdded = 0;
        let channelRemoved = 0;
        let invalidChannel = 0;
        let inaccessibleChannel = 0;

        const channel = message.guild.channels.cache.get(selectedChannel);

        if (!channel) {
          invalidChannel++;
     
        } else {
            if (existingChannel.includes(selectedChannel)) {
              const updatedChannel = existingChannel.filter(id => id !== selectedChannel);
              channeldb.channel = updatedChannel;
              client.db.set(`rolereact_${message.guild.id}`, channeldb);
              channelRemoved++;
            } else {
              existingChannel.push(channel.name);
              channeldb.channelName = channel.name;              
              client.db.set(`rolereact_${message.guild.id}`, channeldb);
              channelAdded++;
            }
        }

        let response = '';

        if (channelAdded > 0) {
          response += `Channel Ajouté : \`${channelAdded} channel\`\n`;
        }
        if (channelRemoved > 0) {
          response += `Channel Retiré : \`${channelRemoved} channel\`\n`;
        }
        if (invalidChannel > 0) {
          response += `Channel Invalide : \`${invalidChannel} channel\`\n`;
        }
        if (inaccessibleChannel > 0) {
          response += `Channel Inaccessible (les membres ne doivent pas avoir la permission de poster des messages) : \`${inaccessibleChannel} channel\`\n`;
        }

        console.log('Response:', response);

        i.reply({ content: response, ephemeral: true });
      }
    })
}
}